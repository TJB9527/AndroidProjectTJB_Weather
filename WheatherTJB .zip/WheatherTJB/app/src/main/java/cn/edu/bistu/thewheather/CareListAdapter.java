package cn.edu.bistu.thewheather;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CareListAdapter extends BaseAdapter {
    private Activity ac;
    private LayoutInflater mInflater;// 动态布局映射
    private List<HashMap<String, Object>> mData = new ArrayList<>();
    private MyDatabase db;

    public CareListAdapter(Context context) {
        this.mInflater = LayoutInflater.from(context);
    }

    public CareListAdapter(Context context, Activity ac) {
        this.ac  = ac;
        this.mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        mData = getData();
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    static class ViewHolder{
        public TextView CityName,Temperature;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder = new ViewHolder();
        if(view==null){
            view = mInflater.inflate(R.layout.carecity_holderview,null);
            holder.CityName = (TextView)view.findViewById(R.id.holder_cityName);
            holder.Temperature = (TextView)view.findViewById(R.id.holder_temperature);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }
        holder.CityName.setText(mData.get(i).get("CityName").toString());
        holder.Temperature.setText(mData.get(i).get("temperature").toString()+"c");
        return view;
    }

    // 初始化一个List
    public List<HashMap<String, Object>> getData() {
        // 新建一个集合类，用于存放多条数据
        ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
        db = new MyDatabase(ac);
        Cursor cursor = null;
        cursor = db.readAllData("CareList");//读取所有数据
        if(cursor.getCount()==0){
            Toast.makeText(ac,"The database is null without data.",Toast.LENGTH_SHORT).show();
        }else {
            while(cursor.moveToNext()){
                HashMap<String, Object> map = new HashMap<>();
                map.put("CityName",cursor.getString(1));
                map.put("temperature",cursor.getString(3));
                list.add(map);
            }
        }
        return list;
    }
}