package cn.edu.bistu.thewheather;

import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyDatabase extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME = "TJBWhether.db";
    private static final int DATABASE_VERSION = 1;
    //表CareList
    private static String TABLE_NAME_Care = "CareList";
    private static String COLUMN_ID = "TheID";
    private static String COLUMN_CityName= "TheCityName";
    private static String COLUMN_ISDAY = "TheIsDay";
    private static String COLUMN_TEMPERATURE = "TheTemperature";
    private static String COLUMN_CONDITION = "TheCondition";
    private static String COLUMN_CONDITIONICON = "TheConditionIcon";
    private static String COLUMN_HUMIDITY = "TheHumidity";
    private static String COLUMN_UPDATETIME = "TheUpdateTime";
    //表AllList
    private static String TABLE_NAME_All = "AllList";
    private static String COLUMN_IDProvince_All = "TheCityID";
    private static String COLUMN_ProvinceName_All = "TheCityName";
    //市级表
    private static String TABLE_NAME_All_City = "AllCityList";
    private static String COLUMN_IDCity_All_City = "TheCityID";
    private static String COLUMN_ProvinceID_All_City = "TheCityProvinceID";
    private static String COLUMN_CityName_All_City = "TheCityName";


    public MyDatabase(@Nullable Context context) {
        super(context, DATABASE_NAME,null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlCare = "CREATE TABLE "+TABLE_NAME_Care+" ("+
                COLUMN_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+
                COLUMN_CityName+" TEXT,"+
                COLUMN_ISDAY+" INTEGER,"+
                COLUMN_TEMPERATURE+" TEXT,"+
                COLUMN_CONDITION+" TEXT,"+
                COLUMN_CONDITIONICON+" TEXT,"+
                COLUMN_HUMIDITY+" TEXT,"+
                COLUMN_UPDATETIME+" TEXT);";

        String sqlAll = "CREATE TABLE "+TABLE_NAME_All+" ("+
                COLUMN_IDProvince_All+" TEXT PRIMARY KEY,"+
                COLUMN_ProvinceName_All+" TEXT);";

        String sqlAllCity = "CREATE TABLE "+TABLE_NAME_All_City+" ("+
                COLUMN_IDCity_All_City+" TEXT,"+
                COLUMN_ProvinceID_All_City+" TEXT,"+
                COLUMN_CityName_All_City+" TEXT," +
                "PRIMARY KEY("+COLUMN_IDCity_All_City+","+COLUMN_ProvinceID_All_City+"));";

        db.execSQL(sqlCare);
        db.execSQL(sqlAll);
        db.execSQL(sqlAllCity);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    /**
     * readAllData
     * @return
     */
    Cursor readAllData(String tableName){
        String sql = "SELECT * FROM "+tableName;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db!=null){
            cursor = db.rawQuery(sql,null);
        }
        return cursor;
    }

    /**
     * readByCondition
     * @param tableName
     * @param ProvinceID
     * @return
     */
    Cursor readByCondition(String tableName,String ProvinceID){
        String sql = "SELECT * FROM "+tableName + " where "+COLUMN_ProvinceID_All_City +"="+ProvinceID;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db!=null){
            cursor = db.rawQuery(sql,null);
        }
        return cursor;
    }

    /**
     * addCareList
     * @param CityName
     * @param isDay
     * @param temperature
     * @param condition
     * @param conditionIcon
     * @param humidity
     * @param updateTime
     */
    public void addCareList(String CityName,int isDay,String temperature,String condition,String conditionIcon,String humidity,String updateTime){
        SQLiteDatabase db = this. getWritableDatabase();//db为可写入对象
        ContentValues cv =new ContentValues();//一条记录
        cv.put(COLUMN_CityName,CityName);
        cv.put(COLUMN_ISDAY,isDay);
        cv.put(COLUMN_TEMPERATURE,temperature);
        cv.put(COLUMN_CONDITION,condition);
        cv.put(COLUMN_CONDITIONICON,conditionIcon);
        cv.put(COLUMN_HUMIDITY,humidity);
        cv.put(COLUMN_UPDATETIME,updateTime);
        long result = db.insert(TABLE_NAME_Care,null,cv);
        if(result==-1)
            Toast.makeText(context,"关注失败!",Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(context,"关注成功!",Toast.LENGTH_SHORT).show();
    }


    /**
     * addAllList
     * @param IDProvince
     * @param ProvinceName
     */
    public void addAllList(String IDProvince,String ProvinceName){
        SQLiteDatabase dbW = this. getWritableDatabase();//db为可写入对象
        SQLiteDatabase dbR = this.getReadableDatabase();

        String sql = "select * from " +TABLE_NAME_All +" where " +COLUMN_IDProvince_All + "=" + IDProvince ;
        Cursor cursor = dbR.rawQuery(sql,null);
        if(cursor.getCount()==0){
            ContentValues cv =new ContentValues();//一条记录
            cv.put(COLUMN_IDProvince_All,IDProvince);
            cv.put(COLUMN_ProvinceName_All,ProvinceName);
            long result = dbW.insert(TABLE_NAME_All,null,cv);
        }else{
            System.out.println("-=-=-=-=-=-=-=-=--addAllList主键冲突，当前数据不做插入=-=-=-=-=-=---=-=-=-=-=");
            return;
        }
    }

    /**
     * addAllCityList
     * @param ProvinceID
     * @param IDCity
     * @param CityName
     */
    public void addAllCityList(String IDCity,String ProvinceID,String CityName){
        SQLiteDatabase dbW = this. getWritableDatabase();//db为可写入对象
        SQLiteDatabase dbR = this.getReadableDatabase();

        String sql = "select * from " +TABLE_NAME_All_City +" where " +COLUMN_IDCity_All_City + "=" + IDCity+ " and " + COLUMN_ProvinceID_All_City+"="+ProvinceID;
        Cursor cursor = dbR.rawQuery(sql,null);
        if(cursor.getCount()==0){
            ContentValues cv =new ContentValues();//一条记录
            cv.put(COLUMN_IDCity_All_City,IDCity);
            cv.put(COLUMN_ProvinceID_All_City,ProvinceID);
            cv.put(COLUMN_CityName_All_City,CityName);
            long result = dbW.insert(TABLE_NAME_All_City,null,cv);
        }else{
            System.out.println("-=-=-=-=-=-=-=-=--=addAllCityList主键冲突，当前数据不做插入-=-=-=-=-=---=-=-=-=-=");
            return;
        }
    }

    /**
     * delete
     * @param CityName
     */
    public void deleteCareList(String CityName){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME_Care," TheCityName=?",new String[]{CityName});
        if(result==-1){
            Toast.makeText(context,"取消关注失败!",Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(context,"取消关注成功!",Toast.LENGTH_SHORT).show();
    }


    /**
     * update
     * @param CityName
     * @param isDay
     * @param temperature
     * @param condition
     * @param conditionIcon
     * @param humidity
     * @param updateTime
     */
    public void updateCareList(String CityName,int isDay,String temperature,String condition,String conditionIcon,String humidity,String updateTime){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_CityName,CityName);
        cv.put(COLUMN_ISDAY,isDay);
        cv.put(COLUMN_TEMPERATURE,temperature);
        cv.put(COLUMN_CONDITION,condition);
        cv.put(COLUMN_CONDITIONICON,conditionIcon);
        cv.put(COLUMN_HUMIDITY,humidity);
        cv.put(COLUMN_UPDATETIME,updateTime);
        int result = db.update(TABLE_NAME_Care,cv,"TheCityName=?",new String[]{CityName});
        if(result==-1){
            Toast.makeText(context,"update error!",Toast.LENGTH_SHORT).show();

        }else
            Toast.makeText(context,"update successful!",Toast.LENGTH_SHORT).show();
    }
}
