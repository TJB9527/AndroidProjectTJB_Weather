package cn.edu.bistu.thewheather;

import net.sourceforge.pinyin4j.*;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;



public class Util {
    public static String pinyin(String str) {
        if(str.equals("香港")){
            return "HongKong";
        }
        if(str.equals("高雄")){
            return "Kaohsiung";
        }
        if(str.equals("闵行")){
            return "minhang";
        }
        //黑龙江地区
        if(str.equals("哈尔滨")){
            return "Harbin";
        }
        if(str.equals("齐齐哈尔")){
            return "Qiqihar";
        }
        //内蒙古地区
        if(str.equals("呼和浩特")){
            return "Hohhot";
        }
        if(str.equals("鄂尔多斯")){
            return "Ordos";
        }
        if(str.equals("锡林浩特")){
            return "Xilinhot";
        }
        if(str.equals("海拉尔")){
            return "Hailar";
        }
        if(str.equals("阿左旗")){
            return "Azuoqi";
        }
        //
        if(str.equals("钓鱼岛")){
            return "Diaoyu Islands";
        }
        //新疆地区
        if(str.equals("乌鲁木齐")){
            return "Urumqi";
        }
        if(str.equals("克拉玛依")){
            return "Karamay";
        }
        if(str.equals("库尔勒")){
            return "Korla";
        }
        if(str.equals("阿拉尔")){
            return "Alar";
        }
        if(str.equals("阿图什")){
            return "Atus";
        }
        //西藏地区
        if(str.equals("那曲")){
            return "Nagqu";
        }
        //青海地区
        if(str.equals("格尔木")){
            return "Golmud";
        }
        //云南地区
        if(str.equals("香格里阿拉")){
            return "Shangri-La";
        }
        //多音字
        if(str.equals("重庆")){
            return "chongqing";
        }
        if(str.equals("厦门")){
            return "xiamen";
        }
        if(str.equals("长春")){
            return "changchun";
        }
        if(str.equals("成都")){
            return "chengdu";
        }
        if(str.equals("长沙")){
            return "changsha";
        }
        Hanyu hanyu = new Hanyu();
        String strPinyin = hanyu.getStringPinYin(str);
        return strPinyin;
    }

    static class Hanyu {
        private HanyuPinyinOutputFormat format = null;
        private String[] pinyin;

        public Hanyu() {
            format = new HanyuPinyinOutputFormat();
            format.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
            pinyin = null;
        }

        //转换单个字符
        public String getCharacterPinYin(char c) {
            try {
                pinyin = PinyinHelper.toHanyuPinyinStringArray(c, format);
            } catch (BadHanyuPinyinOutputFormatCombination e) {
                e.printStackTrace();
            }

            // 如果c不是汉字，toHanyuPinyinStringArray会返回null
            if (pinyin == null) return null;
            // 只取一个发音，如果是多音字，仅取第一个发音
            return pinyin[0];

        }

        //转换一个字符串
        public String getStringPinYin(String str) {
            StringBuilder sb = new StringBuilder();
            String tempPinyin = null;
            for (int i = 0; i < str.length(); ++i) {
                tempPinyin = getCharacterPinYin(str.charAt(i));
                if (tempPinyin == null) {
                    // 如果str.charAt(i)非汉字，则保持原样
                    sb.append(str.charAt(i));
                } else {
                    sb.append(tempPinyin);
                }
            }
            return sb.toString();
        }
    }
}