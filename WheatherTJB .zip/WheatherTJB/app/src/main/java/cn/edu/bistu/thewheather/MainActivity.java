package cn.edu.bistu.thewheather;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Button refresh,care,careList,allCity;
    private RelativeLayout MyHome;
    private ProgressBar loading;//
    private TextView CityNameTV,TheTemperature,Condition,Humidity,UpdateTime;
    private TextInputEditText CityEdt;
    private ImageView TheImageView,searchView,idIvBlack;
    private RecyclerView recyclerView;
    static ArrayList<WeatherModel> weatherModelArrayList;
    private RecycleViewAdapter myAdapter;
    private LocationManager locationManager;
    private  int CODE = 1;
    private String cityName = "";
    private String temperature,condition,conditionIcon,humidity,updateTime;
    private int isDay,recordSP = 0;
    private MyDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //设置窗体全屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        Init();

        //刷新按钮
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CityNameTV.setText(cityName);
                CatchApi(cityName);
                Toast.makeText(MainActivity.this,"refresh successful",Toast.LENGTH_SHORT).show();
            }
        });

        //关注按钮
        care.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean findInSQLite = false;
                Cursor cursor = db.readAllData("CareList");
                System.out.println(cursor);
                while(cursor.moveToNext()){
                    String cityNameSQLite = cursor.getString(1);
                    System.out.println(cityName);
                    System.out.println("当前遍历城市名字："+cityNameSQLite);

                    if(cityName.equals(cityNameSQLite)){
                        findInSQLite = true;
                        break;
                    }
                }
                System.out.println("打印findInSQLite:"+findInSQLite);
                if(findInSQLite == true){
                    db.updateCareList(cityName,isDay,temperature,condition,conditionIcon,humidity,updateTime);
                }else{
                    db.addCareList(cityName,isDay,temperature,condition,conditionIcon,humidity,updateTime);
                }
            }
        });

        //关注列表按钮
        careList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCareAc = new Intent(MainActivity.this,CareListActivity.class);
                startActivity(intentCareAc);
            }
        });

        //所有城市按钮
        allCity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentAllAc = new Intent(MainActivity.this, AllProvinceActivity.class);
                startActivity(intentAllAc);
            }
        });
    }

    /**
     * Init()方法
     */
    public void Init(){
        idIvBlack=findViewById(R.id.idIvBlack);
        refresh = findViewById(R.id.refresh);
        care = findViewById(R.id.care);
        careList = findViewById(R.id.careList);
        allCity = findViewById(R.id.allCity);
        weatherModelArrayList = new ArrayList<>();
        MyHome = findViewById(R.id.MyHome1);
        loading = findViewById(R.id.myBar);
        CityNameTV =findViewById(R.id.CityName);
        TheTemperature=findViewById(R.id.TheTemperature);
        Condition = findViewById(R.id.Condition);
        CityEdt = findViewById(R.id.EdtCity);
        TheImageView = findViewById(R.id.TheImgView);
        Humidity = findViewById(R.id.humidity);
        UpdateTime = findViewById(R.id.updateTime);
        searchView  = findViewById(R.id.SrcButton);
        recyclerView =findViewById(R.id.TheRecycle);
        myAdapter = new RecycleViewAdapter(this,weatherModelArrayList);
        db = new MyDatabase(MainActivity.this);
        recyclerView.setAdapter(myAdapter);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);  //定位
        //申请权限----上网
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED&&ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},CODE);
        }
        Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

        cityName = getIntent().getStringExtra("CityName");
        if(cityName!=null) {
            CityNameTV.setText(cityName);  //点击关注城市列表项显示对应天气
            System.out.println("当前点击的关注城市列表项是："+cityName);
        }
        else {
            cityName = "Beijing"; //默认显示北京天气
            CityNameTV.setText("Beijing");
        }
        CatchApi(cityName);

        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cityName = CityEdt.getText().toString();
                //如果用户输入城市不为空，判断用户输入的城市名是否在SharedPreferences缓存在，如果在直接将缓存中数据取出，如果不在直接在线访问api
                if(cityName.isEmpty()){
                    Toast.makeText(MainActivity.this,"输入不能为空，请重新输入",Toast.LENGTH_SHORT).show();
                }
                else{
                    boolean findInSP = false;
                    SharedPreferences spGet = getSharedPreferences("data",MODE_PRIVATE);
                    //遍历SharedPreferences
                    for(int i = recordSP; i > recordSP-3 && i > 0 ; i--){
                        String cityNameSP = spGet.getString("cityName"+i,"");
                        System.out.println("当前从缓存中遍历到的城市----"+"键是：cityName"+i+"------值是："+cityNameSP);
                        if(cityName.equals(cityNameSP))
                            findInSP = true;
                    }

                    System.out.println("打印findInSP："+findInSP);
                    if(findInSP==true){
                        //获取值
                        CityNameTV.setText(cityName);
                        isDay = spGet.getInt("isDay"+recordSP,1);
                        temperature = spGet.getString("temperature"+recordSP,"");
                        condition = spGet.getString("condition"+recordSP,"");
                        conditionIcon = spGet.getString("conditionIcon"+recordSP,"");
                        humidity = spGet.getString("humidity"+recordSP,"");
                        updateTime = spGet.getString("updateTime"+recordSP,"");
                        //填充布局
                        TheTemperature.setText(temperature);
                        Picasso.get().load("http:".concat(conditionIcon)).into(TheImageView);
                        Condition.setText(condition);
                        Humidity.setText(humidity);
                        UpdateTime.setText(updateTime);
                        loadBackGround(isDay);  //加载白天/夜晚背景图
                    }else{
                        CityNameTV.setText(cityName);
                        CatchApi(cityName);
                    }
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == CODE){
            if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"Permission grand!",Toast.LENGTH_SHORT).show();
            }
            else
                Toast.makeText(this,"Please to Permission grand!",Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    /**
     * 根据输入城市名字在线访问API获取天气信息
     * @param cityName
     */
    private void CatchApi(String cityName){
        System.out.println("当前访问的城市是："+cityName);
        String Url = "http://api.weatherapi.com/v1/forecast.json?key=4f069b78b5a04bc997721113210310&q="+cityName+"&days=1&aqi=yes&alerts=yes";
        System.out.println(Url);
        CityNameTV.setText(cityName);
        //RequestQueue是一个请求队列对象，它可以缓存所有的HTTP请求，然后按照一定的算法并发地发出这些请求
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        //解析URI，返回网页上的Jason结果集
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, Url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                loading.setVisibility(View.GONE);   //隐藏滚动条
                idIvBlack.setVisibility(View.VISIBLE);   //背景设为“可见”
                weatherModelArrayList.clear();  //arraylist保存viewholder
                try {
                    //解析JSONObject，获取指定键值对内容
                    temperature = response.getJSONObject("current").getString("temp_c");
                    isDay = response.getJSONObject("current").getInt("is_day"); //白天返回1，夜晚返回0
                    condition = response.getJSONObject("current").getJSONObject("condition").getString("text");//天气状况（晴、多云、阴、雨、小雪等）对应英文描述字符
                    conditionIcon = response.getJSONObject("current").getJSONObject("condition").getString("icon");//condition对应描述图标
                    humidity = response.getJSONObject("current").getString("humidity");
                    updateTime = response.getJSONObject("current").getString("last_updated");

                    //填充控件布局
                    TheTemperature.setText(temperature+"c");
                    Picasso.get().load("http:".concat(conditionIcon)).into(TheImageView); //Picasso-安卓的一个图片加载框架
                    Condition.setText(condition);
                    Humidity.setText(humidity);
                    UpdateTime.setText(updateTime);
                    loadBackGround(isDay);

                    System.out.println("打印condition："+condition);
                    System.out.println("打印conditionIcon:"+conditionIcon);
                    System.out.println("-------------当前城市访问结束-------------");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                try {
                    JSONObject forecastObj = response.getJSONObject("forecast");
                    JSONObject forecast0 = forecastObj.getJSONArray("forecastday").getJSONObject(0);
                    JSONArray hourArray = forecast0.getJSONArray("hour");
                    for(int i = 0; i < hourArray.length(); i++){
                        i++;
                        JSONObject hourObj = hourArray.getJSONObject(i);
                        String time = hourObj.getString("time");
                        String temper = hourObj.getString("temp_c");
                        String img = hourObj.getJSONObject("condition").getString("icon");
                        String wind = hourObj.getString("wind_kph");
                        weatherModelArrayList.add(new WeatherModel(time,temper,img,wind));
                    }
                    myAdapter.notifyDataSetChanged();//让Adapter重新加载数据
                } catch (JSONException e) {
                    e.printStackTrace();
                    System.out.println("-------------JSONException");
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error);
                Toast.makeText(MainActivity.this,"No matching location found",Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(jsonObjectRequest);

        //缓存用户查询的城市的天气信息
        SharedPreferences.Editor sp = getSharedPreferences("data",MODE_PRIVATE).edit();
        recordSP++;
        sp.putString("cityName"+recordSP,cityName);
        sp.putInt("isDay"+recordSP,isDay);
        sp.putString("temperature"+recordSP,temperature);
        sp.putString("condition"+recordSP,condition);
        sp.putString("conditionIcon"+recordSP,conditionIcon);
        sp.putString("humidity"+recordSP,humidity);
        sp.putString("updateTime"+recordSP,updateTime);
        sp.commit();
    }

    /**
     * 切换主界面白天/黑夜背景图
     * @param isDay
     */
    public void loadBackGround(int isDay){
        if(isDay==1){  //加载白天背景图
            System.out.println("123");
            Picasso.get().load("https://i.loli.net/2021/10/03/RDPyKq1MevnUc4Y.jpg").into(idIvBlack);
        }
        else{   //加载夜晚夜晚背景图
            System.out.println("456");
            Picasso.get().load("https://i.loli.net/2021/10/03/RDPyKq1MevnUc4Y.jpg").into(idIvBlack);
        }
    }
}