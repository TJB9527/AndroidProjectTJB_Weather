package cn.edu.bistu.thewheather;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CareListActivity extends AppCompatActivity {
    private Context context;
    private ListView lv;
    private List<HashMap<String,Object>> mData = new ArrayList<>();
    private MyDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_care_list);
        db = new MyDatabase(CareListActivity.this);

        lv = findViewById(R.id.lv);
        CareListAdapter careAdapter = new CareListAdapter(this,this);
        lv.setAdapter(careAdapter);

        mData = careAdapter.getData();

        //列表项点击事件
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intentMainAc = new Intent(CareListActivity.this,MainActivity.class);
                intentMainAc.putExtra("CityName",mData.get(i).get("CityName").toString());
                startActivity(intentMainAc);
                finish();
            }
        });

        //listView长按事件
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(CareListActivity.this);
                builder.setItems(new String[]{"取消关注","设为提醒城市"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                db.deleteCareList(mData.get(i).get("CityName").toString());
                                careAdapter.notifyDataSetChanged();
                                break;
                            case 1:
                                break;
                            default:
                                break;
                        }
                    }
                });
                builder.create().show();
                return true;
            }
        });
    }

}