package cn.edu.bistu.thewheather;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.http2.Http2Reader;


public class AllProvinceActivity extends AppCompatActivity {
    private Activity ac;
    private Context context;
    private ListView lv;
    private List<HashMap<String,Object>> mData = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
    private HashMap<String, Object> map;
    private MyDatabase db;
    private Cursor cursor;
    private Handler handler;

    public AllProvinceActivity(){};

    public AllProvinceActivity(Context context) {
        this.context = context;
    }

    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_province);

        db = new MyDatabase(AllProvinceActivity.this);
        lv = findViewById(R.id.lv);

        sendRequest();  //执行子进程在线访问API，并将返回的数据解析后保存到数据库中

        //在主线程里添加handler实例，并实现handleMessage()方法
        handler = new Handler(){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);
                if(msg.what == 1){
                    System.out.println("qqqqqqqqqqqqqqqqqqqqqqqqq");
                    cursor = db.readAllData("AllList");
                    while (cursor.moveToNext()){
                        map = new HashMap<>();
                        map.put("id",cursor.getString(0));
                        map.put("name",cursor.getString(1));
                        System.out.println("省列表当前map对象："+map.toString());
                        list.add(map);
                    }
                    LoadAdapter(list);
                }
            }
        };

        //列表项点击事件
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intentAllCity = new Intent(AllProvinceActivity.this,AllCityActivity.class);
                String ProvinceID = (String) list.get(i).get("id");
                String ProvinceName = (String) list.get(i).get("name");
                intentAllCity.putExtra("id",ProvinceID);
                intentAllCity.putExtra("name",ProvinceName);
                startActivity(intentAllCity);
            }
        });
    }

    /**
     * 加载Adapter
     * @param list
     */
    public void LoadAdapter(ArrayList<HashMap<String, Object>> list){
        AllAdapter allAdapter = new AllAdapter(this,this,list);
        lv.setAdapter(allAdapter);
    }


    //子线程执行JSON格式数据解析并通过Message和Handler实现在主线程更新UI操作
    public void sendRequest(){
        new Thread(new Runnable(){
            @Override
            public void run() {
                String responseData = "";
                try {
                    String Url = "http://guolin.tech/api/china/";
                    OkHttpClient client = new OkHttpClient();
                    Request request = new Request.Builder().url(Url).build();
                    Response response = client.newCall((request)).execute();
                    responseData = response.body().string();  //responseData实际就是api返回的数组，此处化为String类型
                    try {
                        JSONArray allArray = new JSONArray(responseData);
                        for(int i = 0; i < allArray.length(); i++){
                            JSONObject provinceObject = allArray.getJSONObject(i);
                            String idCity = provinceObject.getString("id");
                            String cityName = provinceObject.getString("name");
                            System.out.println("当前省："+cityName);
                            db.addAllList(idCity,cityName);
                        }
                        Message message = new Message();
                        message.what = 1;
                        handler.sendMessage(message);

                    }catch (JSONException e){
                        e.printStackTrace();
                    }
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }).start();
    }

}