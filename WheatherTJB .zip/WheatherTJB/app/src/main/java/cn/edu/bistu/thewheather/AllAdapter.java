package cn.edu.bistu.thewheather;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class AllAdapter extends BaseAdapter {
    private Context context;
    private Activity ac;
    private LayoutInflater mInflater;;// 动态布局映射
    private List<HashMap<String, Object>> mData = new ArrayList<>();
    private ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
    private MyDatabase db;

    public AllAdapter(Context context) {
        this.mInflater = LayoutInflater.from(context);
    }

    public AllAdapter(Context context, Activity ac, ArrayList<HashMap<String, Object>> list) {
        this.ac  = ac;
        this.mInflater = LayoutInflater.from(context);
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    static class ViewHolder{
        public TextView Name;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        AllAdapter.ViewHolder holder = new AllAdapter.ViewHolder();
        if(view==null){
            view = mInflater.inflate(R.layout.all_holderview,null);
            holder.Name = (TextView)view.findViewById(R.id.all_holder_cityName);
            view.setTag(holder);
        }else{
            holder = (AllAdapter.ViewHolder) view.getTag();
        }
        holder.Name.setText(list.get(i).get("name").toString());
        return view;
    }
}
