package cn.edu.bistu.thewheather;



import static cn.edu.bistu.thewheather.MainActivity.weatherModelArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;


public class RecycleViewAdapter<Content> extends RecyclerView.Adapter<RecycleViewAdapter.ViewHolder> {
    private Context context;

    public RecycleViewAdapter(Context context, java.util.ArrayList<WeatherModel> arrayList) {
        this.context = context;
        ArrayList = arrayList;
    }

    private ArrayList<WeatherModel> ArrayList;

    @NonNull
    @Override
    public RecycleViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.weatheritem,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecycleViewAdapter.ViewHolder holder, int position) {
        WeatherModel model = weatherModelArrayList.get(position);
        SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd hh:mm");
        SimpleDateFormat outPut = new SimpleDateFormat("yyyy-MM-dd hh:mm aa");
        holder.TheItemTemperature.setText(model.getTemperature()+"c");
        holder.windSpeed.setText(model.getWindSpeed()+"Km/h");
        Picasso.get().load("http://".concat(model.getIcon())).into(holder.TheItemCondition);
        try{
            Date t;
            t = input.parse(model.getTime());
            holder.time.setText(outPut.format(t));
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return ArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView time,TheItemTemperature,windSpeed;
        private ImageView TheItemCondition;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            time=itemView.findViewById(R.id.time);
            TheItemCondition=itemView.findViewById(R.id.TheItemCondition);
            windSpeed =itemView.findViewById(R.id.WindSpeed);
            TheItemTemperature=itemView.findViewById(R.id.TheItemTemperature);
        }
    }
}
